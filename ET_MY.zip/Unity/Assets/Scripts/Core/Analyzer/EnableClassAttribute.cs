namespace ET
{
    public class EnableClassAttribute: BaseAttribute
    {
    }
}