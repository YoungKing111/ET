﻿namespace ET
{
    // Unit的组件有这个接口说明需要传送
    public interface ITransfer
    {
        
    }
}