﻿namespace ET.Client
{
    public enum WindowID
    {
        WindowID_Invaild = 0,
        WindowID_MessageBox,
        WindowID_Lobby,    //房间界面
        WindowID_Login,     //登录界面
        WindowID_RedDot,   //红点测试界面
        WindowID_Helper,   //提示界面
    }
}