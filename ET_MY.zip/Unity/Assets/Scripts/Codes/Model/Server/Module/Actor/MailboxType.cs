﻿namespace ET.Server
{
    public enum MailboxType
    {
        MessageDispatcher,
        UnOrderMessageDispatcher,
        GateSession,
    }
}