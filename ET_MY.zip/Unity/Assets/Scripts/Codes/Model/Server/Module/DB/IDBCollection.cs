namespace ET.Server
{
    public interface IDBCollection
    {
    }
}