namespace ET.Server
{
    public struct RobotInvokeArgs
    {
        public string Content { get; set; }
    }
}