﻿namespace ET.Server
{
	public class SessionInfoComponent : Entity
	{
		public Session Session;
	}
}