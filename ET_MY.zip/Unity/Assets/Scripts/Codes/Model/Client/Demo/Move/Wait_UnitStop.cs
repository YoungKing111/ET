﻿namespace ET.Client
{
    public struct Wait_UnitStop: IWaitType
    {
        public int Error
        {
            get;
            set;
        }
    }
}