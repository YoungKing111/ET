﻿namespace ET.Client
{
    public struct Wait_SceneChangeFinish: IWaitType
    {
        public int Error
        {
            get;
            set;
        }
    }
}