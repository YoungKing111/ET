namespace ET.Client
{
    [ComponentOf(typeof(Session))]
    public class RouterCheckComponent: Entity, IAwake
    {
    }
}