﻿namespace ET
{
	public interface INumericWatcher
	{
		void Run(Unit unit, EventType.NumbericChange args);
	}
}
