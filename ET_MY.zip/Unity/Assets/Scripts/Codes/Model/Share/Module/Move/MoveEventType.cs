﻿namespace ET
{
    namespace EventType
    {
        public struct MoveStart
        {
            public Unit Unit;
        }

        public struct MoveStop
        {
            public Unit Unit;
        }
    }
}