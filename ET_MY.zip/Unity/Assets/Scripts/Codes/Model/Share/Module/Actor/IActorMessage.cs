﻿namespace ET
{
    // 不需要返回消息
    public interface IActorMessage: IMessage
    {
    }

    public interface IActorRequest: IRequest
    {
    }

    public interface IActorResponse: IResponse
    {
    }
}