namespace ET
{
    public static class ConstValue
    {
        public const string RouterHttpHost = "127.0.0.1";
        public const int RouterHttpPort = 10300;
        public const int SessionTimeoutTime = 30 * 1000;
    }
}