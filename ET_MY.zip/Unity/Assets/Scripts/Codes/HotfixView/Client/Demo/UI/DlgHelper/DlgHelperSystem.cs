﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.UI;

namespace ET.Client
{
	[FriendOf(typeof(DlgHelper))]
	public static  class DlgHelperSystem
	{

		public static void RegisterUIEvent(this DlgHelper self)
		{
		 
		}

		public static void ShowWindow(this DlgHelper self, Entity contextData = null)
		{
		}

		 

	}
}
