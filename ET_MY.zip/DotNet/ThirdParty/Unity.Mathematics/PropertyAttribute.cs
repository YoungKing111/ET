﻿namespace Unity.Mathematics.UnityEngine
{
    public class PropertyAttribute
    {
    }
}